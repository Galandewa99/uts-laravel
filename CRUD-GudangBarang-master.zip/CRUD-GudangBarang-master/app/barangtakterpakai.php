<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class barangtakterpakai extends Model
{
    //
}
